const MangaDeJujutsu = {
  Titulo: "Jujutsu Kaisen Cap.1",
  Autor: "Gege Akutami",
  AnoDeLançamento: "2020",
  PalavrasChaves: "Jujutsu, Kaisen, Jujutsu Kaisen, jujutsu, kaisen, jujutsu kaisen,Jujutsu Kaisen Cap 1, jujutsu kaisen cap 1",
  ResumoHistoria: "Jujutsu Kaisen é uma serie e mangá escrita por Gege que mostra um jovem estudante chamado Itadori que trilha seu caminho com seus amigos e seu sensei,Satoru gojo,porem acaba comendo um item amaldiçoado e ganhando um poder imensuravel,sua Tecnica Amaldiçoada,do rei das maldições Ryomen Sukuna",
  count: 1
};
console.log(JSON.parse(JSON.stringify(MangaDeJujutsu)));